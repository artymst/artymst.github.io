\# PhysicsGraphPy

Beginner-friendly Python library for kinematics, projectile motion, graphing, and animation.



\## Install

`pip install physicsgraphpy`



\## Usage

See example scripts in the `examples` folder.



